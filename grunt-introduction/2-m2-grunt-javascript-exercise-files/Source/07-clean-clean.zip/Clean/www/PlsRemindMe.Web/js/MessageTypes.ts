module plsRemindMe.MessageTypes {
    
    export var SelectedReminderStateChanged = "SelectedReminderStateChanged";
    export var NewReminderAdded = "NewReminderAdded";

}