
module plsRemindMe.Templates {

    export var UpcomingReminders: string = "reminders.upcoming";
    export var ReminderStats: string = "reminders.stats";
    export var Reminders: string = "reminders.main";
}
