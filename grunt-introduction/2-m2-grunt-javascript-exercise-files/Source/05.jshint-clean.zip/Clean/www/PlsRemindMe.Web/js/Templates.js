var plsRemindMe;
(function (plsRemindMe) {
    (function (Templates) {
        Templates.UpcomingReminders = "reminders.upcoming";
        Templates.ReminderStats = "reminders.stats";
        Templates.Reminders = "reminders.main";
    })(plsRemindMe.Templates || (plsRemindMe.Templates = {}));
    var Templates = plsRemindMe.Templates;
})(plsRemindMe || (plsRemindMe = {}));
