var fs = require('fs');

module.exports = function(grunt) {

  // Project configuration.
  grunt.initConfig({
    // Task configuration.
 
  });

    // Default task.
    grunt.registerTask('default', ['checkFileSize']);
    
    grunt.registerTask('checkFileSize', 'Task to check file Size', function(){
        var folderToScan = './files';        
        
        grunt.file.recurse(folderToScan, function(abspath, rootdir, subdir, filename){
            if( grunt.file.isFile(abspath)){
                
                var stats = fs.statSync(abspath);
                var asBytes = stats.size / 1024;
                grunt.log.writeln("Found file %s with size of %s kb", filename, asBytes);               
            }

        });
    
    });

};
