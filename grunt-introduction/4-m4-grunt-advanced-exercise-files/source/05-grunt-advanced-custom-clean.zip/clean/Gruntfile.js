module.exports = function(grunt) {

  // Project configuration.
  grunt.initConfig({
    // Task configuration.
 
  });

    // Default task.
    grunt.registerTask('default', ['checkFileSize']);
    

};
