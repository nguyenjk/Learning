/*
 * grunt-checkFileSize
 * https://github.com/Derik/
 *
 * Copyright (c) 2014 derikwhittaker
 * Licensed under the MIT license.
 */

'use strict';
var fs = require('fs');

module.exports = function(grunt) {

  // Please see the Grunt documentation for more information regarding task
  // creation: http://gruntjs.com/creating-tasks
    function dumpDebugInformation(options){
        if( options.debug !== undefined && options.debug ){
            grunt.log.writeflags(options, 'Options');            
        }        
    }
    function verifyFolderExists(folderPath){
        if( folderPath === "" || folderPath === undefined ){
            grunt.fail.fatal("The provided folderToScan was empty or not provided");
        }
    
        if ( !grunt.file.exists(folderPath)) {
            grunt.fail.fatal("The provided folderToScan was not found");   
        }
        
        if( !grunt.file.isDir(folderPath)){
            grunt.fail.fatal("The provided folderToScan was not a folder")   
        }
    }

    function checkFileSizes(options){
        grunt.file.recurse(options.folderToScan, function(abspath, rootdir, subdir, filename){
            if( grunt.file.isFile(abspath)){

                var stats = fs.statSync(abspath);
                var asBytes = stats.size / 1024;
                grunt.log.writeln("Found file %s with size of %s kb", filename, asBytes);               
            }

        });         
    }


  grunt.registerTask('checkFileSize', 'The best Grunt plugin ever.', function() {
        var options = this.options({
            folderToScan : '',
            debug: false
        });     
//debug
//validation
//action

      dumpDebugInformation(options);
            
      verifyFolderExists(options.folderToScan);
        
      checkFileSizes(options);   

  });

};
