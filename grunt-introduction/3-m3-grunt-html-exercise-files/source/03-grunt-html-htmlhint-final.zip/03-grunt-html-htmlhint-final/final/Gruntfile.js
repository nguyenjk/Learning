'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        htmlhint: {
            templates: {
                options: {
//                    'doctype-first': false,
                    'attr-lower-case': true,
                    'attr-value-not-empty': true,
//                    'tag-pair': true,
//                    'tag-self-close': true,
//                    'tagname-lowercase': true,
//                    'id-class-value': true,
//                    'id-class-unique': true,
//                    'src-not-empty': true,
//                    'img-alt-required': true
                },
                src: ['www/PlsRemindMe.Web/Templates/**/*.html']
            }
        }       

    });

    grunt.loadNpmTasks('grunt-htmlhint');

    grunt.registerTask('default', ['htmlhint']);

}