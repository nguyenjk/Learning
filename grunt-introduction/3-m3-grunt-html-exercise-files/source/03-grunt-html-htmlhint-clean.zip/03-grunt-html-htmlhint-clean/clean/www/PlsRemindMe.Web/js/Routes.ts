module plsRemindMe.Routes {
    export var UpcomingReminders = "api/Reminders/Upcoming";
    export var ReminderStats = "api/Reminders/Stats";
    export var CreateReminder = "api/Reminders/Create";
    export var DeleteReminder = "api/Reminders/Delete";

    export var ReminderConnections = "api/Connections/ReminderConnections";
    
}