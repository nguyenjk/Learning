'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        less: {
            development: {
                options: {
                    cleancss: false,
                    compress: false,
                    strictImports: false,
                    modifyVars: {
                        "color-primary-dark-blue": "NOT_BLUE"
                    }
                    //paths: ["www/PlsRemindMe.Web/Content"]
                },
//                files: {
//                    "www/PlsRemindMe.Web/Content/plsremind.me.common.css": "www/PlsRemindMe.Web/Content/plsremind.me.common.less",
//                    //"www/PlsRemindMe.Web/Content/plsremind.me.core.css": "www/PlsRemindMe.Web/Content/plsremind.me.core.less"
//                }

                files: [ {
                    // no need for files, the config below should work
                    expand: true,
                    cwd:    "www/PlsRemindMe.Web/Content/",
                    dest:   "www/PlsRemindMe.Web/Content/",
                    src:    ["plsremind.me.*.less"],
                    ext:    ".css",
                    extDot: "last"
                } ]            
            }
        }
    });

    grunt.loadNpmTasks('grunt-contrib-less');

    grunt.registerTask('default', ['less']);

}