'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        
        csslint: {
            strict: {
                options: {
                },
                src: ['www/PlsRemindMe.Web/Content/plsremind.me.common.css']

            },
            laxed: {
                options: {
                    csslintrc: "lintrules.json"
                },
                src: ['www/PlsRemindMe.Web/Content/plsremind.me.*.css']

            }
        }     
 
    });
    
    grunt.loadNpmTasks('grunt-contrib-csslint');

    grunt.registerTask('default', ['csslint']);

}