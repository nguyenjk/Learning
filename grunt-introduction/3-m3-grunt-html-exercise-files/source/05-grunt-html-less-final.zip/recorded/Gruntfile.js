'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
          less: {
            development: {
                options: {
                    cleancss: false,
                    compress: false,    
                    modifyVars: {
                        "color-primary-dark-blue": "NOT_BLUE"
                    }
    
                },
                files: [ {
                    expand: true,
                    cwd:    "www/PlsRemindMe.Web/Content/",
                    dest:   "www/PlsRemindMe.Web/Content/",
                    src:    ["plsremind.me.*.less"],
                    ext:    ".css",
                    extDot: "last"
                } ] 

            }
        }
    });
    
    grunt.loadNpmTasks('grunt-contrib-less');

    grunt.registerTask('default', ['less']);

}