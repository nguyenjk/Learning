'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        cssmin: {
            minify: {
                expand: true,
                cwd: 'www/PlsRemindMe.Web/Content/',
                src: ["plsremind.me.*.css", "!*.min.css"],
                dest: 'www/PlsRemindMe.Web/Content/',
                ext: '.min.css',
                extDot: 'last'
            },
            concat: {
                options: {
                },
                files: {
                    'www/PlsRemindMe.Web/Content/plsremind.me.min.css': ['www/PlsRemindMe.Web/Content/plsremind.me.*.css']
                }
          },            
     } 

    });
    
    grunt.loadNpmTasks('grunt-contrib-cssmin');

    grunt.registerTask('default', ['cssmin']);

}