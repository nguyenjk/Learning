'use strict';

module.exports = function (grunt) {
    
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        htmlmin: {    
            dev: {
                options: {
                    removeEmptyAttributes: true,
                    removeEmptyElements: true,                                   
                    removeRedundantAttributes : true,
                    removeComments : true,                         
                    removeOptionalTags : true,
                    collapseWhitespace: true,
                },                
                files: [ {
                    expand: true,
                    cwd:    "www/PlsRemindMe.Web/Templates/",
                    dest:   "www/PlsRemindMe.Web/Templates/",
                    src:    ["*.tmpl.html"],
                    ext:    ".min.html",
                    extDot: "last"
                } ]   
        
            }
        }      

    });
    
    grunt.loadNpmTasks('grunt-contrib-htmlmin');
    
    grunt.registerTask('default', ['htmlmin']);

}