$(document).ready(function(){
	var $para1 = $(".para1");

	$para1[0].innerText = 
	$para1[0].innerText.replace(/Lorem/,"LOREM")
	.replace(/dolor/,"DOLOR")
	.replace(/amet/,"AMET")
	.replace(/adipiscing/,"ADIPISCING")
	.replace(/Donec/,"DONEC")
	.replace(/justo/,"JUSTO")
	.replace(/justo/,"JUSTO")
	.replace(/luctus/,"LUCTUS")
	.replace(/ut/,"UT")
	.replace(/in/,"IN")
	.replace(/eret/,"ERET")
	.replace(/ante/,"ANTE")
	.replace(/congue/,"CONGUE")
	.replace(/ornare/,"ORNARE")
	.replace(/felis/,"FELIS")
	.replace(/hendrerit/,"HENDRERIT")
	.replace(/elementum/,"ELEMENTUM")
	.replace(/nam/,"NAM")
	.replace(/facilisis/,"FACILISIS")
	.replace(/Phasellus/,"PHASELLUS")
	.replace(/turpis/,"TURPIS")
	.replace(/libero/,"LIBERO")
	.replace(/dictum/,"DICTUM")
	.replace(/eu/,"EU")
	.replace(/nam/,"NAM")
	.replace(/metus/,"METUS")
	.replace(/Integer/,"INTEGER")
	.replace(/malesuada/,"MALESUADA")
	.replace(/sed/,"SED")
	.replace(/nisi/,"NISI")
	.replace(/quis/,"QUIS");

});

// this is the .para1:
/*
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec ac justo posuere justo varius luctus vel ut nisl. In id erat nec ante malesuada congue. Integer ornare ornare felis, et hendrerit metus elementum quis. Nam lacinia facilisis luctus. Phasellus vel turpis id libero varius dictum vitae eu quam. Nam imperdiet metus urna. Integer vehicula malesuada massa, sed sodales nisi molestie quis.
*/

// this is the .para3:
/*
Pellentesque aliquam posuere nisl et ultricies. Etiam sollicitudin turpis consequat ante ultricies ut venenatis massa ultrices. Sed eget mauris ipsum. Maecenas aliquet, dolor ac feugiat sodales, dui libero bibendum erat, a ullamcorper dolor nisl a est. Ut sagittis ligula at mi ultrices malesuada id feugiat arcu. Vivamus quis augue vitae leo porta dapibus. Pellentesque mattis pretium tortor at accumsan. Integer et augue dui, at auctor mauris. Duis pretium, elit a aliquam pretium, mauris arcu fermentum lacus, eu viverra justo nibh et sapien. 
*/